# SKILL_HOMOLOGACION_FUENTES_DIGITALES_LF

## Identidad canónica
- codigo_activo: ACT-0053
- nombre_canonico: SKILL_HOMOLOGACION_FUENTES_DIGITALES_LF
- version: V0_3 (REV3 — correcciones menores post-verificación V0_2; sin cambio de alcance)
- estado_documental: CANDIDATO
- estado_operativo: READ_ONLY
- runtime_estado: CANDIDATE_READ_ONLY
- impacto_automatico: BLOQUEADO
- operation_code: HOMOLOGACION_FUENTES_DIGITALES_LF
- linea_codigo: GOV_SKILLS_LINEAMIENTOS
- owner: Cristhian
- creado_bajo: ACT-0043 / CREACION_SKILL_LF (gates 1-2-9 PASS, evidencia Supabase 2026-06-11)
- evento_origen_fase1: lf_eventos id=251 (DDL_FASE1_COMPLETADO)

## Propósito
Homologar registros de `lf_capture_records` hacia `lf_homologated_records`
usando la taxonomía canónica `lf_taxonomia_lf` (OPCION_A, evento id=251),
con ejecución controlada por sesiones en `lf_sandbox_runs`.
Nombrada por dominio de capacidad, no por consumidor (lección ACT-0052).

## MVP — definición (resuelve bloqueante B1, decisión owner 2026-06-11)
El MVP V0_x es un **SUBCONJUNTO AUDITABLE**, NO una ruta ejecutable lineal:
- Steps MVP: S1-A, S1-B, S1-C, S2-A, S7-A.
- Significado: son los steps mínimos cuya evidencia debe existir para que
  una sesión sea auditable, ejecutados en su posición natural del flujo.
- La ruta ejecutable completa sigue siendo S1-A→S1-B→S1-C→S2-A→S3-A→
  S4-A→S5-A→S6-A→S7-A. Una sesión READ_ONLY puede saltar S3-S6 y cerrar
  en S7-A únicamente si ningún registro entró a transformación.

## Matriz modo → writes permitidos (resuelve bloqueante B2)
| Modo | lf_sandbox_runs | lf_homologated_records | lf_operation_execution_steps | lf_eventos | Otra tabla |
|---|---|---|---|---|---|
| READ_ONLY | NO | NO | NO | NO (solo PROPUESTA de evento, registro fuera de la skill con aprobación owner) | NO |
| DRY_RUN | SÍ (sesión propia) | SÍ (solo execution_mode='DRY_RUN' + run_id) | SÍ (evidencia por step) | SÍ (solo eventos de auditoría, con aprobación owner) | NO |
| PRODUCTION_REGISTER | BLOQUEADO | BLOQUEADO | BLOQUEADO | BLOQUEADO | BLOQUEADO |

Cualquier write fuera de esta matriz = violación → ABORT + evento de error.

## Umbrales y definiciones canónicas (resuelve bloqueante B3)
- `taxonomia_cobertura_pct` umbral: **>= 80** (proxy conservador aprobado
  por owner 2026-06-11, marcado REVISABLE; ajustar requiere decisión owner).
- `payload_homologado` COMPLETO (fundado en readback de esquema
  lf_homologated_records, 2026-06-11):
  - Obligatorios (NOT NULL sin default): capture_record_id, run_id
  - Obligatorios operativos para status HOMOLOGADO_DRY_RUN:
    taxonomia_id resuelto, topic_homologado, funnel_stage_homologado,
    source_type_homologado, homolog_package (jsonb no vacío)
  - Siempre: execution_mode = 'DRY_RUN' en V0_x
- Matriz determinista de estados (S4-A) — mutuamente excluyente (decisión owner 2026-06-11):
  | Estado | Condición exclusiva |
  |---|---|
  | HOMOLOGADO_DRY_RUN | payload_homologado_COMPLETO = TRUE AND taxonomia_id resuelto y válido AND evidencias mínimas completas |
  | OBSERVADO | taxonomia_id resuelto y válido AND NOT NULL completos AND falta ≥1 campo operativo no crítico (topic/funnel/source_type/package) → review_notes obligatorio |
  | RECHAZADO | falta taxonomia_id OR sin match verificable de taxonomía OR falta obligatorio NOT NULL OR evidencia insuficiente OR incumplimiento de campos críticos → rejection_reason obligatorio |
  Orden de evaluación (cascada): primero RECHAZADO; si no aplica, OBSERVADO; si no aplica, HOMOLOGADO_DRY_RUN. Garantiza exclusividad.

## Arquitectura — 7 slices · 9 steps
| Orden | Slice | Step | Nombre | MVP |
|---|---|---|---|---|
| 1 | S1 | S1-A | verify_sources | ✔ |
| 2 | S1 | S1-B | verify_taxonomia | ✔ |
| 3 | S1 | S1-C | verify_sandbox_mode | ✔ |
| 4 | S2 | S2-A | inspect_record | ✔ |
| 5 | S3 | S3-A | transform | |
| 6 | S4 | S4-A | assign_status | |
| 7 | S5 | S5-A | build_package | |
| 8 | S6 | S6-A | consumer_gate | |
| 9 | S7 | S7-A | audit | ✔ |

Nota de alcance: V0_1 formalizó 9 steps por decisión owner (Opción A,
2026-06-11). V0_2 NO amplía alcance: solo endurece contratos (REV2).

## Tablas del dominio (existentes — Fase 1, evento id=251)
lf_capture_records (input) · lf_taxonomia_lf · lf_sandbox_runs
(production_blocked=TRUE) · lf_homologated_records (default DRY_RUN) ·
lf_eventos · lf_operation_execution_steps. Esta skill NO crea tablas.

## Separación propuesta vs registro de evento (S7-A)
- S7-A SIEMPRE produce `evento_propuesto` (payload JSON listo).
- El REGISTRO en lf_eventos es una acción separada, fuera del step,
  ejecutada solo con aprobación explícita del owner y solo en DRY_RUN.
- En READ_ONLY la sesión cierra con la propuesta como evidencia final.

## Gates de promoción
CANDIDATO → EN_REVISION → PRUEBA_SANDBOX → APROBADO. Ninguno automático.
